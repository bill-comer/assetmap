package com.mockrunner.mock.web;

public interface WebConstants
{
    public final static String DATE_FORMAT_HEADER = "EEE, d MMM yyyy HH:mm:ss z";
}
